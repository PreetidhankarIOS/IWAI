//
//  HomeVC.swift
//  IWAI
//
//  Created by preeti dhankar on 11/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit
import Foundation

class HomeVC: BaseVC {
    
    @IBOutlet weak var homeTableView: UITableView!
    var imageIcon = ["location","compass","settings"]
    var tital = ["Voyage Planner","Assets and Navigational Information on National Waterways","Admin Access"]
    var subtital = ["Submit for Approvls","View Update data","River Navigation System"]
    
    
    
    // MARK: - Life cycle
    
    override func initialSetup() {
        self.registerXib()
        
    }
    
    private func registerXib() {
        self.homeTableView.registerCell(nibName: CarouselViewForHeaderTableViewCell.reusableIdentifier)
        self.homeTableView.registerCell(nibName: HomePageTableViewCell.reusableIdentifier)
        
        
    }
    
    
    
}

extension HomeVC : UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1 + subtital.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            
            guard let cell = self.homeTableView.dequeueReusableCell(withIdentifier: CarouselViewForHeaderTableViewCell.reusableIdentifier) as? CarouselViewForHeaderTableViewCell else {
                fatalError("CarouselViewForHeaderTableViewCell not found")
            }
            
            
            return cell
        }
            
        else{
            guard let cell =
                self.homeTableView.dequeueReusableCell(withIdentifier: HomePageTableViewCell.reusableIdentifier) as? HomePageTableViewCell else {
                    fatalError("HomePageTableViewCell not found")
            }
            
            cell.logoImage.image = UIImage(named: imageIcon[indexPath.row-1] )
            cell.titleLib.text = tital[indexPath.row-1]
            cell.subTitleLib.text = subtital[indexPath.row-1]
            cell.bgview.viewWithShadow()
            cell.gotoNextBtn.ButtonWithShadow()
            cell.selectionStyle = .none
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 1:
            let Scene = VoyagePlannerVC.instantiate(fromAppStoryboard: .voyagePlanner)
            self.navigationController?.pushViewController(Scene, animated: true)
        case 2:
            let Scene = NaviagtionVC.instantiate(fromAppStoryboard: .naviagtion)
            self.navigationController?.pushViewController(Scene, animated: true)
            
        default:
            let Scene = AdminAccessVC.instantiate(fromAppStoryboard: .adminAccess)
            self.navigationController?.pushViewController(Scene, animated: true)
        }
    }
}
