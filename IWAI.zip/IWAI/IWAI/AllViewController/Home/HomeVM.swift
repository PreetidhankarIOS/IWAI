//
//  HomeVM.swift
//  IWAI
//
//  Created by preeti dhankar on 11/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import Foundation
import UIKit

protocol HomeVMDelegate: class {

}

class HomeVM {

    // MARK: - Properties
    // MARK: - Public
    
    weak var delegate: HomeVMDelegate?
}
