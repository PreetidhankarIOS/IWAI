//
//  MapForPlannerVC.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit
import MapKit

struct Location {
    let title: String
    let latitude: Double
    let longitude: Double
}



class MapForPlannerVC: BaseVC,MKMapViewDelegate {
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    let locations = [
        Location(title: "Subansiri River, Assam, India",    latitude: 27.730566, longitude:     94.329559),
        Location(title: "Godavari River, India", latitude: 16.708548, longitude: 82.118683),
        Location(title: "Aydar Rover, India",     latitude: 13.014031, longitude: 80.257919),
        Location(title: "Cauvery River, India",     latitude: 12.528591, longitude: 75.993629),
        Location(title: "Krishna River, India",     latitude:     15.754239, longitude: 80.897270)
    ]
    
    
    // MARK: - Life cycle
    
    override func initialSetup() {
        
        registerMap()
        
    }
    private func registerMap() {
        
        for location in locations {
            let annotation = MKPointAnnotation()
            annotation.title = location.title
            annotation.coordinate = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
            mapView.addAnnotation(annotation)
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last as CLLocation? else { return }
        
        let userCenter = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        
        let region = MKCoordinateRegion(center: userCenter, span: MKCoordinateSpan(latitudeDelta: 180, longitudeDelta: 180))
        
        mapView.setRegion(region, animated: true)
        
    }
    
    func centerMapOnLocation(_ location: CLLocation, mapView: MKMapView) {
        let regionRadius: CLLocationDistance = 1000
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: regionRadius * 2.0, longitudinalMeters: regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }
        
        let identifier = "Annotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        
        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.canShowCallout = true
        } else {
            annotationView!.annotation = annotation
        }
        
        return annotationView
    }
    
}
