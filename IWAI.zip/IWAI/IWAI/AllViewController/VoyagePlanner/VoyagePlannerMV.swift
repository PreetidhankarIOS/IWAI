//
//  VoyagePlannerMV.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//


import Foundation
import UIKit

protocol VoyagePlannerMVDelegate: class {

}

class VoyagePlannerMV {

    // MARK: - Properties
    // MARK: - Public
    
    weak var delegate: VoyagePlannerMVDelegate?
}
