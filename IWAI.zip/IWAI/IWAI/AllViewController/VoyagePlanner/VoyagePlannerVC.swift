//
//  VoyagePlannerVC.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit
import DropDown

class VoyagePlannerVC: BaseVC,WWCalendarTimeSelectorProtocol {
    
    @IBOutlet weak var voyageTableView: UITableView!
    
    var singleDate: Date = Date()
    var multipleDates: [Date] = []
    
    
    var arrVehical = ["NW-1 Ganga-Bhagirathi-Hooghly River System (Haldia - Allahabad)","NW-3 West Coast Canal","NW-2 Brahmaputra River (Dhubri - Sadiya)","NW-4","Gujarat","Arunachal Pradesh","Assam","Bihar"]
      
      let categoryDrop = DropDown()
      lazy var dropDowns: [DropDown] = {
          return [
              self.categoryDrop
          ]
      }()

    // MARK: - Life cycle
    
    override func initialSetup() {
        self.registerXib()
    }
    
    private func registerXib() {
        self.voyageTableView.registerCell(nibName: VoyagesPlannerTableViewCell.reusableIdentifier)
    }
}

extension VoyagePlannerVC : UITableViewDelegate,UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            guard let cell = self.voyageTableView.dequeueReusableCell(withIdentifier: VoyagesPlannerTableViewCell.reusableIdentifier) as? VoyagesPlannerTableViewCell else {
                fatalError("CarouselViewForHeaderTableViewCell not found")
            }
        self.forHeaderViewCell(cell, indexpath: IndexPath.init(row: 0, section: 0))
        
      cell.bgView.viewWithShadow()
        return cell
    }

}
