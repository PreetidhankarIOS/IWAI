//
//  voyagePlannerBtnAction.swift
//  IWAI
//
//  Created by preeti dhankar on 13/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import Foundation
import UIKit
import DropDown


extension VoyagePlannerVC {
  
 func forHeaderViewCell(_ cell: VoyagesPlannerTableViewCell, indexpath: IndexPath) {
    
    cell.calclateFeasibilty.tag = indexpath.row
      cell.calclateFeasibilty.addTarget(self, action: #selector(self.calclateFeasibiltyAction(_:)), for: .touchUpInside)
    cell.datebtn.addTarget(self, action: #selector(datebtnAction(sender:)), for: .touchUpInside)
    cell.datebtn.tag = indexpath.row
    
    cell.originNWBtn.addTarget(self, action: #selector(originNWBtnAction(sender:)), for: .touchUpInside)
    cell.originNWBtn.tag = indexpath.row
    
    
    }
    
////////////////////////Button Action   Header Cell //////////////////////////////////////////
            
     @objc func calclateFeasibiltyAction (_ sender : UIButton) {
   
           let buttonTag = sender.tag
         let indexPath = IndexPath.init(item: buttonTag, section: 0)
        if (voyageTableView.cellForRow(at: indexPath) as? VoyagesPlannerTableViewCell) != nil {
               let homeScene = MapForPlannerVC.instantiate(fromAppStoryboard: .mapPlanner)
             self.navigationController?.pushViewController(homeScene, animated: true)
         }
     }
    
    
    @objc func originNWBtnAction (sender : UIButton) {
        let buttonTag = sender.tag
             let indexPath = IndexPath.init(item: buttonTag, section: 0)
        if (voyageTableView.cellForRow(at: indexPath) as? VoyagesPlannerTableViewCell) != nil {
            
                self.categoryDrop.anchorView = sender
                self.categoryDrop.bottomOffset = CGPoint(x: 0, y: sender.bounds.height)
                self.categoryDrop.dataSource.removeAll()
                self.categoryDrop.dataSource.append(contentsOf: self.arrVehical)
                self.categoryDrop.selectionAction = { [unowned self] (index, item) in
                    sender.setTitle(item, for: .normal)
                    // self.uplordDcument = item
                    //debugPrint(self.uplordDcument)
                    
                }
                self.categoryDrop.show()
                
        }
        
    }
    
    @objc func datebtnAction (sender : UIButton) {
        
        let buttonTag = sender.tag
         let indexPath = IndexPath.init(item: buttonTag, section: 0)
        if (voyageTableView.cellForRow(at: indexPath) as? VoyagesPlannerTableViewCell) != nil {
            
    let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
     selector.delegate = self
     selector.optionCurrentDate = singleDate
     selector.optionCurrentDates = Set(multipleDates)
     selector.optionCurrentDateRange.setStartDate(multipleDates.first ?? singleDate)
     selector.optionCurrentDateRange.setEndDate(multipleDates.last ?? singleDate)
     selector.optionStyles.showDateMonth(true)
     selector.optionStyles.showMonth(false)
     selector.optionStyles.showYear(true)
     selector.optionStyles.showTime(false)
     present(selector, animated: true, completion: nil)

         }
     }
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {

               let dateString = date.stringFromFormat("dd MMMM'yy")
              debugPrint(dateString)
            //  self.dateOfBirthBtn.setTitle("\(dateString)", for: .normal)
         
       }
    
    
}
