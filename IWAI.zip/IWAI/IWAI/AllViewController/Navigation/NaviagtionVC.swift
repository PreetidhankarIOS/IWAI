//
//  NaviagtionVC.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit


class NaviagtionVC: BaseVC {
    
  
    @IBOutlet weak var topView: UIView!
    
    
    
    // MARK: - Life cycle
    
    override func initialSetup() {
        
        self.topView.dropShadow()
    }
    
    private func registerXib() {
        
        
    }
    
  ////Button Action///////////
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func filterBtnAction(_ sender: Any) {
        
        
         let homeScene = filterNavigationVC.instantiate(fromAppStoryboard: .naviagtion)
         self.navigationController?.pushViewController(homeScene, animated: true)
    }
    
    @IBAction func selectNationWaterBtnAction(_ sender: UIButton) {
 
    }
    
    

}
