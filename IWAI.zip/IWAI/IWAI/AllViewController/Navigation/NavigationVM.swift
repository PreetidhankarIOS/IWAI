//
//  NavigationVM.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import Foundation
import UIKit

protocol NavigationVMDelegate: class {

}

class NavigationVM {

    // MARK: - Properties
    // MARK: - Public
    
    weak var delegate: NavigationVMDelegate?
}
