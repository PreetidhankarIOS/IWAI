//
//  filterNavigationBtnAction.swift
//  IWAI
//
//  Created by preeti dhankar on 15/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import Foundation
import UIKit

extension filterNavigationVC {
 
func filterNavigation(_ cell: FilterNavigationTableViewCell, indexpath: IndexPath) {
   
     cell.applyfilterBtn.tag = indexpath.row
     cell.applyfilterBtn.addTarget(self, action: #selector(self.applyfilterBtnAction(_:)), for: .touchUpInside)
    
    
    cell.selectAssetTypeBtn.tag = indexpath.row
        cell.selectAssetTypeBtn.addTarget(self, action: #selector(self.selectAssetTypeBtnAction(_:)), for: .touchUpInside)
   
   
   }
    
    

    ////////////////////////Button Action   Header Cell //////////////////////////////////////////
                
         @objc func applyfilterBtnAction (_ sender : UIButton) {
       
               let buttonTag = sender.tag
             let indexPath = IndexPath.init(item: buttonTag, section: 0)
            if (filterTableView.cellForRow(at: indexPath) as? FilterNavigationTableViewCell) != nil {
                
                self.showCuntryCodeBGView.isHidden = false
//                   let homeScene = MapForPlannerVC.instantiate(fromAppStoryboard: .mapPlanner)
//                 self.navigationController?.pushViewController(homeScene, animated: true)
             }
         }
    
             @objc func selectAssetTypeBtnAction (_ sender : UIButton) {
           
                   let buttonTag = sender.tag
                 let indexPath = IndexPath.init(item: buttonTag, section: 0)
                if (filterTableView.cellForRow(at: indexPath) as? FilterNavigationTableViewCell) != nil {
                     
                     self.showCuntryCodeBGView.isHidden = false

                 }
             }
    
}
