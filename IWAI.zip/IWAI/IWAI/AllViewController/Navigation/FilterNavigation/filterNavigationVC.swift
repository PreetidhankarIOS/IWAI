//
//  filterNavigationVC.swift
//  IWAI
//
//  Created by preeti dhankar on 15/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit

import DropDown

class filterNavigationVC: BaseVC,WWCalendarTimeSelectorProtocol {
    
    @IBOutlet weak var filterTableView: UITableView!
    
    var singleDate: Date = Date()
    var multipleDates: [Date] = []
    

    @IBOutlet weak var slecteAssetTV: UITableView!
    @IBOutlet weak var showCuntryCodeBGView: UIView!
    @IBOutlet weak var whitViewBg: UIView!
    var arrVehical = ["NW-1 Ganga-Bhagirathi-Hooghly River System","NW-3 West Coast Canal","NW-2 Brahmaputra River (Dhubri - Sadiya)","NW-4","NW-5","NW-6","NW-7","NW-8"]
    
    let categoryDrop = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.categoryDrop
        ]
    }()
    
    // MARK: - Life cycle
    
    override func initialSetup() {
        self.registerXib()
    }
    
    private func registerXib() {
        showCuntryCodeBGView.isHidden = true
        self.slecteAssetTV.allowsMultipleSelection = true
        self.slecteAssetTV.allowsMultipleSelectionDuringEditing = true
         self.filterTableView.registerCell(nibName: FilterNavigationTableViewCell.reusableIdentifier)
    }
    
    
    @IBAction func slectAssetBtnAction(_ sender: UIButton) {
        
        if sender.tag == 61 {
            self.showCuntryCodeBGView.isHidden = true
        }else if sender.tag == 18 {
           self.showCuntryCodeBGView.isHidden = true
        }

        
    }
    
    
    
    
    
}

extension filterNavigationVC : UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == slecteAssetTV {
             return 10
        }else{
             return 1
        }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if tableView == slecteAssetTV {
                    guard let cell = self.slecteAssetTV.dequeueReusableCell(withIdentifier: CountryCodeTableviewCell.reusableIdentifier) as? CountryCodeTableviewCell else {
                        fatalError("CountryCodeTableviewCell not found")
                    }
                    cell.bgmainView.viewWithShadow()
                    return cell

               }else{
            
                    guard let cell = self.filterTableView.dequeueReusableCell(withIdentifier: FilterNavigationTableViewCell.reusableIdentifier) as? FilterNavigationTableViewCell else {
                        fatalError("CarouselViewForHeaderTableViewCell not found")
                    }
                    self.filterNavigation(cell, indexpath: IndexPath.init(row: 0, section: 0))
                    cell.bgView.viewWithShadow()
                    return cell

               }
        
        
            }
    
}


class CountryCodeTableviewCell: UITableViewCell {
    
    @IBOutlet weak var titleLib: UILabel!
    @IBOutlet weak var bgmainView: UIView!
    

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
           super.init(style: style, reuseIdentifier: reuseIdentifier)
           self.selectionStyle = .none
       }

       required init?(coder aDecoder: NSCoder) {
           super.init(coder: aDecoder)
       }

       override func setSelected(_ selected: Bool, animated: Bool) {
           super.setSelected(selected, animated: animated)
           self.accessoryType = selected ? .checkmark : .none
       }
}


