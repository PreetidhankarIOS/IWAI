//
//  filterNavigationMV.swift
//  IWAI
//
//  Created by preeti dhankar on 15/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import Foundation
import UIKit

protocol filterNavigationMVDelegate: class {

}

class filterNavigationMV {

    // MARK: - Properties
    // MARK: - Public
    
    weak var delegate: filterNavigationMVDelegate?
}
