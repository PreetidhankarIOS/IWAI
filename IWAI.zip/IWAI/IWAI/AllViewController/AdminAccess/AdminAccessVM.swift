//
//  AdminAccessVM.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import Foundation
import UIKit

protocol AdminAccessVMDelegate: class {

}

class AdminAccessVM {

    // MARK: - Properties
    // MARK: - Public
    
    weak var delegate: AdminAccessVMDelegate?
}
