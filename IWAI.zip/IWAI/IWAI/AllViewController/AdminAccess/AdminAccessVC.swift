//
//  AdminAccessVC.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit

class AdminAccessVC: BaseVC {
    
    @IBOutlet weak var homeTableView: UITableView!

    
    
    
    // MARK: - Life cycle
    
    override func initialSetup() {
       // self.registerXib()
        
    }
    
    private func registerXib() {
        self.homeTableView.registerCell(nibName: CarouselViewForHeaderTableViewCell.reusableIdentifier)
        self.homeTableView.registerCell(nibName: HomePageTableViewCell.reusableIdentifier)
        
        
    }
    
    
    
}

//extension AdminAccessVC : UITableViewDelegate,UITableViewDataSource {
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//
//        return 1 + subtital.count
//
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//        if indexPath.row == 0 {
//
//            guard let cell = self.homeTableView.dequeueReusableCell(withIdentifier: CarouselViewForHeaderTableViewCell.reusableIdentifier) as? CarouselViewForHeaderTableViewCell else {
//                fatalError("CarouselViewForHeaderTableViewCell not found")
//            }
//
//
//            return cell
//        }
//
//        else{
//            guard let cell =
//                self.homeTableView.dequeueReusableCell(withIdentifier: HomePageTableViewCell.reusableIdentifier) as? HomePageTableViewCell else {
//                    fatalError("HomePageTableViewCell not found")
//            }
//
//            cell.logoImage.image = UIImage(named: imageIcon[indexPath.row-1] )
//            cell.titleLib.text = tital[indexPath.row-1]
//            cell.subTitleLib.text = subtital[indexPath.row-1]
//            cell.bgview.viewWithShadow()
//            cell.gotoNextBtn.ButtonWithShadow()
//
//            return cell
//        }
//
//    }
//
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        switch indexPath.row {
//        case 1:
//            <#code#>
//        case 2:
//            <#code#>
//
//        default:
//            <#code#>
//        }
//    }
//}
