//
//  WalkThroughVC.swift
//  WalkthroughDemo
//
//  Created by Appinventiv on 26/10/17.
//  Copyright © 2017 Appinventiv. All rights reserved.
//

import UIKit

class WalkThroughVC: UIViewController {

    // MARK:- Variables
    //==================
    let tutorialImages: [UIImage] = [#imageLiteral(resourceName: "ic_tutorial screen_01"),#imageLiteral(resourceName: "ic_tutorial screen_02"),#imageLiteral(resourceName: "ic_tutorial screen_03"),#imageLiteral(resourceName: "ic_tutorial screen_04@1")]
   
    // MARK:- IBOutlets
    //==================
    @IBOutlet weak var tutorialCollectionView: UICollectionView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var skipButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    // MARK:- Life Cycle
    //====================
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initialSetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       
    }

    // MARK:- IBActions
    //==================
    @IBAction func nextButtonTapped(_ sender: UIButton) {
        
        if self.pageControl.currentPage == self.tutorialImages.count - 1 {
            self.navigateToNextScreen()
        }else{
            self.tutorialCollectionView.scrollToItem(at: IndexPath(item: self.pageControl.currentPage + 1, section: 0), at: .centeredHorizontally, animated: true)
            self.pageControl.currentPage += 1
        }
        
    }
    
    @IBAction func skipButtonTapped(_ sender: UIButton) {
        self.navigateToNextScreen()
    
    }
}

// MARK:- Functions
//==================
extension WalkThroughVC {

    /// Initial Setup
    private func initialSetup() {
        
        self.tutorialCollectionView.delegate = self
        self.tutorialCollectionView.dataSource = self
        self.pageControl.numberOfPages = self.tutorialImages.count
        
    }
    
    /// Navigate To Next Screen
    private func navigateToNextScreen() {
        
   // AppRouter.goToHome()
      let homeScene = HomeVC.instantiate(fromAppStoryboard: .Home)
              self.navigationController?.pushViewController(homeScene, animated: true)
        
    }
}

// MARK:- Collection View Delegate and DataSource
//=================================================
extension WalkThroughVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.tutorialImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueCell(with: TutorialCollectionCell.self, indexPath: indexPath)
        
        cell.imageView.image = self.tutorialImages[indexPath.item]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return collectionView.frame.size
    }
}

// MARK:- Scroll View Delegate
//===============================
extension WalkThroughVC {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        let offset = scrollView.contentOffset
        let page = offset.x / self.view.bounds.width
        
        if Int(page) == self.tutorialImages.count-1 {
            self.nextButton.setTitle("DONE", for: .normal)
        } else {
            self.nextButton.setTitle("NEXT", for: .normal)
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {

        let offset = scrollView.contentOffset
        let page = offset.x / self.view.bounds.width
        self.manageScroll(forPage: Int(page))
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {

        let offset = scrollView.contentOffset
        let page = offset.x / self.view.bounds.width
        self.manageScroll(forPage: Int(page))
    }
    
    func manageScroll(forPage page : Int) {
        
        self.pageControl.currentPage = page
    }
}


// MARK:- Tutorial Collection Cell
//==================================
class TutorialCollectionCell: UICollectionViewCell {
    
    //MARK:- Variables
    //==================
    @IBOutlet weak var imageView: UIImageView!
    
}
