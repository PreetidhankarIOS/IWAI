//
//  CarouselViewForHeaderTableViewCell.swift
//  NewProject
//
//  Created by Developer on 20/02/20.
//  Copyright © 2020 Harsh Vardhan Kushwaha. All rights reserved.
//

import UIKit

class CarouselViewForHeaderTableViewCell: UITableViewCell,FSPagerViewDataSource,FSPagerViewDelegate  {

    fileprivate let imageNames = ["11",
    "22",
    "33",
    "44",
    "55"
    ]
       //fileprivate let imageNames = ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg","6.jpg","7.jpg"]
       fileprivate var numberOfItems = 5
    
    @IBOutlet weak var pagerView: FSPagerView!
    @IBOutlet weak var pageControl: FSPageControl!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        pagerView.dataSource = self
        pagerView.delegate = self

        self.pagerView.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "cell")
        self.pagerView.itemSize = FSPagerView.automaticSize
        self.pagerView.automaticSlidingInterval = 5.0
        self.pagerView.interitemSpacing = 10
        self.pagerView.itemSize = CGSize(width: 300, height: 180)
        self.pageControl.numberOfPages = self.imageNames.count
        self.pageControl.contentHorizontalAlignment = .right
        self.pageControl.contentInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    

    // MARK:- FSPagerView DataSource
       
       public func numberOfItems(in pagerView: FSPagerView) -> Int {
           return self.numberOfItems
       }
       
       public func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
           let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
           cell.imageView?.image = UIImage(named: self.imageNames[index])
           cell.imageView?.contentMode = .scaleAspectFill
           cell.imageView?.clipsToBounds = true
           cell.textLabel?.text = index.description+index.description
           return cell
       }
       
       
       // MARK:- FSPagerView Delegate
       
       func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
           pagerView.deselectItem(at: index, animated: true)
           pagerView.scrollToItem(at: index, animated: true)
       }
       
       func pagerViewWillEndDragging(_ pagerView: FSPagerView, targetIndex: Int) {
           self.pageControl.currentPage = targetIndex
       }
       
       func pagerViewDidEndScrollAnimation(_ pagerView: FSPagerView) {
           self.pageControl.currentPage = pagerView.currentIndex
       }
       
    
    
    
    
}
