//
//  VoyagesPlannerTableViewCell.swift
//  IWAI
//
//  Created by preeti dhankar on 12/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit

class VoyagesPlannerTableViewCell: UITableViewCell {
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var calclateFeasibilty: UIButton!
    @IBOutlet weak var originNWBtn: UIButton!
    @IBOutlet weak var originTerminalBtn: UIButton!
    @IBOutlet weak var destiNWBtn: UIButton!
    @IBOutlet weak var destiTerminal: UIButton!
    
    @IBOutlet weak var EstiWeightOfCargo: UITextField!
    
    @IBOutlet weak var horizontalClearnceReqTxt: UITextField!
    @IBOutlet weak var reqDraughtTxt: UITextField!
    @IBOutlet weak var cleranceReqTxt: UITextField!
    @IBOutlet weak var datebtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
