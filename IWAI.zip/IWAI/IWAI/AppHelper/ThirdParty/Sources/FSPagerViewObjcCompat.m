//
//  FSPagerViewObjcCompat.m
//  FSPagerView
//
//  Created by Wenchao Ding on 2018/9/24.
//  Copyright © 2018 Wenchao Ding. All rights reserved.
//

#import "FSPagerViewObjcCompat.h"

NSUInteger const FSPagerViewAutomaticDistance = 0;
CGSize const FSPagerViewAutomaticSize = { .width = 0, .height = 0 };
