//
//  AppDelegate.swift
//  IWAI
//
//  Created by preeti dhankar on 08/07/20.
//  Copyright © 2020 iwai.gov.in. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

 static let shared = UIApplication.shared.delegate as! AppDelegate
 var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.goToFirstScreen()
        return true
    }
    
    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
}

extension AppDelegate {
    
    /// Setup First screen
    private func goToFirstScreen() {
            
//            let tutorialDisplayed = AppUserDefaults.value(forKey: .tutorialDisplayed).stringValue
//            if tutorialDisplayed.bool ?? false {
                //AppRouter.goToHome()
               // setMenuHome()
//
//            } else {
              //  AppRouter.goToWalkthrough()
            //}
        
            UINavigationBar.appearance().barTintColor = UIColor(red: 128.0/255.0, green: 222.0/255.0, blue: 234.0/255.0, alpha: 1.0)
     
        }
}

extension String {
    
    var bool: Bool? {
        switch self.lowercased() {
        case "true", "t", "yes", "y", "1":
            return true
        case "false", "f", "no", "n", "0":
            return false
        default:
            return nil
        }
    }
}

extension AppDelegate{
    
  func setMenuHome(){

    self.window = UIWindow(frame: UIScreen.main.bounds)
    
              // Create content and menu controllers
              let navigationController = UINavigationController(rootViewController: HomeVC.instantiate(fromAppStoryboard: .Home))
              self.window?.rootViewController = navigationController
             AppUserDefaults.save(value: true, forKey: .tutorialDisplayed)
              self.window?.backgroundColor = .white
              self.window?.makeKeyAndVisible()
     }
}
